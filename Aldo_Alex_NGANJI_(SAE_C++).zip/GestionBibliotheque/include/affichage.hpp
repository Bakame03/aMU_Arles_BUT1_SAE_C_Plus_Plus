#ifndef AFFICHAGE_HPP
#define AFFICHAGE_HPP
#include "types.hpp"

void afficherFicheLivre(const Livre& l);
void afficherListePagination(const Bibliotheque& b);

#endif