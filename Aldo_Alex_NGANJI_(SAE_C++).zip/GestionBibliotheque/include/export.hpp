#ifndef EXPORT_HPP
#define EXPORT_HPP
#include "types.hpp"
#include <string>

void exporterEnHTML(const Bibliotheque& b, std::string cheminFichier);

#endif