#ifndef RECHERCHE_HPP
#define RECHERCHE_HPP
#include "types.hpp"

void chercherParIsbn(const Bibliotheque& b);
void chercherParTitre(const Bibliotheque& b);

#endif